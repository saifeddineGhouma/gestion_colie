<body>
  @yield('contenu')
</body>
