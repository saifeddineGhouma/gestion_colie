<!DOCTYPE html>
<html lang="en">
@include('part_admin.auth.layout.head')
@include('part_admin.auth.layout.body')
</html>
