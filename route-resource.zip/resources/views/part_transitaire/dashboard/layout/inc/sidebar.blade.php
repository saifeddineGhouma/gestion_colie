<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
       @include('part_transitaire.dashboard.layout.inc.sider-bar-header')
       @include('part_transitaire.dashboard.layout.inc.sider-bar-menu')
    </div>
</div>
