<div id="app">

            @include('part_transitaire.dashboard.layout.inc.sidebar')


 </div>
