<!DOCTYPE html>
<html lang="en">
@include('part_transitaire.dashboard.layout.head')
@include('part_transitaire.dashboard.layout.body')
</html>
