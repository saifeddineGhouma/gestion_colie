<body>
  @yield('contenu')
</body>
