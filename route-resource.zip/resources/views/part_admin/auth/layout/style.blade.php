<link rel="stylesheet" href="{{asset('assets/css/main/app.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/pages/auth.css')}}">
<link rel="shortcut icon" href="{{asset('assets/images/logo/favicon.svg')}}" type="image/x-icon">
<link rel="shortcut icon" href="{{asset('assets/images/logo/favicon.png')}}" type="image/png">
