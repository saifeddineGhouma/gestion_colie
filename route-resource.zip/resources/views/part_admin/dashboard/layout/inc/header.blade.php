<div id="app">

            @include('part_admin.dashboard.layout.inc.sidebar')
            

 </div>
