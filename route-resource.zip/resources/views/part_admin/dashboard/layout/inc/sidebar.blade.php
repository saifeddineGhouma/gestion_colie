<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
       @include('part_admin.dashboard.layout.inc.sider-bar-header')
       @include('part_admin.dashboard.layout.inc.sider-bar-menu')
    </div>
</div>
