<!DOCTYPE html>
<html lang="en">
@include('part_admin.dashboard.layout.head')
@include('part_admin.dashboard.layout.body')
</html>
