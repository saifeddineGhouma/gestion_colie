@extends('part_admin.dashboard.layout.global')
@section('contenu')

@endsection
